Upute za objavu web stranice na GitHub Pages:

1. Prijavi se na https://github.com i otvori svoj repozitorij ili kreiraj novi.
2. Uploadaj sve datoteke iz ovog ZIP paketa (index.html).
3. U repozitoriju idi na Settings -> Pages.
4. Pod Source izaberi granu 'main' ili 'master' i folder '/root' (korijen).
5. Klikni Save.
6. Pričekaj par minuta, stranica će biti dostupna na adresi:
   https://<tvoj-github-korisnički-ime>.github.io/<ime-repozitorija>/
7. Otvori taj URL u pregledniku i vidi svoju stranicu s molitvama i YouTube videima.
8. Za izmjene, samo izmijeni index.html i ponovo uploadaj.

Ako trebaš pomoć, slobodno se javi!